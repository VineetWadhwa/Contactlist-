//Require the library 
const mongoose = require('mongoose');
//Connect the database
mongoose.connect('mongodb://localhost/contact_list_db');
 
//Acqire the connection to check is it Succesful?
const db = mongoose.connection;
//If error then show the error
db.on('error',console.error.bind(console,'Error connecting to db:'));

//If not error i.e up and running  , then print the message
db.once('open',function(){
    console.log('Sucessfully connected to the database');
});