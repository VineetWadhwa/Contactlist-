const express = require('express');
const path =    require('path');
const port = 880;

const db = require('./config/mongoose');
const Contact = require('./models/con');
const app = express();


app.set('view engine','ejs');
 app.set('views', path.join(__dirname,'views'));
 app.use(express.urlencoded());
 app.use(express.static('assets'))

//  //middleware1
//  app.use(function(req,res,next){
//      // console.log("middleware 1 called");
//      req.myName = "Vini";
//       next();
//  });
   
//  //middleware2
//  app.use(function(req,res,next){
// //console.log("Middleware 2 called");
// console.log("My name from MW2",req.myName);
// next();
//  });
var contactList = [
    {
       name:"Vineet",
       phone:"9812390935" 
    },
    {
        name:"Rahul",
        phone:"123456789"
    },
    {
        name:"Thanos",
        phone:"234567655"
    },
];




app.get('/',function(req,res){
  // console.log("From the get route controller",req.myName);
 // console.log(__dirname);
 // res.send('<h1>Ya it is running</h2>');

 Contact.find({},function(err,contacts){
      if(err)
      {
          console.log('Error in fetching the contacts from db');
          return;
      }
      return res.render('home',{
        title:"Contact List",
        contact_list : contacts
    });
 });

    
});
   
     app.get('/practice',function(req,res){
         return res.render('practice',{title:'Let us play with Ejs'});
     });
     
app.post('/create-contact',function(req,res){
    // return res.redirect('/practice');
    // contactList.push({
    //     name:req.body.name,
    //     phone:req.body.phone
    // });
    // contactList.push(req.body);
    Contact.create({
        name : req.body.name,
        phone: req.body.phone
    },function(err,newContact){
        if(err)
        {
            console.log("Error in creating a contact!");
            return;
        }
        console.log("*****",newContact);
        return res.redirect('back');
    });
    //return res.redirect('back');

});
 // For deleting a contact
app.get('/delete-contact/',function(req,res){
    //get the query from the url
    console.log(req.query);
    let id = req.query.id;
 
//find the contact in the database using and delete it.
    // let contactIndex = contactList.findIndex(contact => contact.phone == phone);
    // if(contactIndex != -1){
    //     contactList.splice(contactIndex, 1);
    // }

    Contact.findByIdAndDelete(id,function(err){
        if(err)
{
    console.log('Error in deleting the database');
    return;
}
   return res.redirect('back');
    });

});

    app.listen(port,function(err){
        if(err){
            console.log('Error is running in the server',err)
        }
            console.log('Yup! My Express server is running on port:',port);
   });