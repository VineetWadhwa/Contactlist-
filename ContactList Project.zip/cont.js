const express = require('express');
const port = 8100;

const app = express();


app.get('/',function(req,res){
    res.send('Ya it is running');
});



app.listen(port,function(err){
     if(err){
         console.log('Error is running in the server',err)
     }
         console.log('Yup! My Express server is running on port:',port);
});